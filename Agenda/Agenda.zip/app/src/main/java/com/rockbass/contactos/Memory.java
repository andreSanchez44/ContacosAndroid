package com.rockbass.contactos;

import java.util.ArrayList;
import java.util.List;

public class Memory {
    public static final List<Persona> PERSONAS =
            new ArrayList<>();
}

package com.rockbass.contactos;

public class Persona {
    public String nombre;
    public String apellidoPaterno, apellidoMaterno;
    public int edad;
    public String telefono;
    public String email;
}

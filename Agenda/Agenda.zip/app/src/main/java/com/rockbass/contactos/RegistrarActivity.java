package com.rockbass.contactos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class RegistrarActivity extends AppCompatActivity {

    private EditText editTextNombre, editTextApellidoPaterno, editTextApellidoMaterno,
            editTextEdad, editTextTelefono, editTextEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);

        editTextNombre = findViewById(R.id.editTextNombre);
        editTextApellidoPaterno = findViewById(R.id.editTextApellidoPaterno);
        editTextApellidoMaterno = findViewById(R.id.editTextApellidoMaterno);
        editTextEdad = findViewById(R.id.editTextEdad);
        editTextTelefono = findViewById(R.id.editTextTelefono);
        editTextEmail = findViewById(R.id.editTextEmail);

        FloatingActionButton fabRegistrar = findViewById(R.id.fab_registrar);
        fabRegistrar.setOnClickListener(
                view->{
                    Persona persona = new Persona();
                    persona.nombre = editTextNombre.getText().toString();
                    persona.apellidoPaterno = editTextApellidoPaterno.getText().toString();
                    persona.apellidoMaterno = editTextApellidoMaterno.getText().toString();
                    persona.edad = Integer.parseInt(editTextEdad.getText().toString());
                    persona.telefono = editTextTelefono.getText().toString();
                    persona.email = editTextEmail.getText().toString();

                    Memory.PERSONAS.add(persona);

                    finish();
                }
        );
    }
}
